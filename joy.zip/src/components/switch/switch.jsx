import * as React from "react"
import "./switch.scss"

const Switch = ({ handleToggle }) => {
  const isBrowser = typeof window !== "undefined"
  const [isChecked, setIsChecked] = React.useState(false)

  const toggleSwitch = () => {
    const newChecked = !isChecked
    setIsChecked(newChecked)
    if (isBrowser) {
      localStorage.setItem("darkMode", JSON.stringify(newChecked))
    }
  }

  React.useEffect(() => {
    if (isChecked) {
      document.body.classList.add("night")
    } else {
      document.body.classList.remove("night")
    }

    return () => {
      if (isBrowser) {
        localStorage.removeItem("darkMode")
      }
    }
  }, [isChecked, isBrowser])

  return (
    <div className="switch-wrapper">
      <div className="sun"></div>
      <div className="toggle-wrapper">
        <input
          id="switch"
          type="checkbox"
          onChange={toggleSwitch}
          checked={isChecked}
          onClick={handleToggle}
        />
        <label htmlFor="switch" id="toggle">
          Toggle
        </label>
      </div>
      <div className="moon"></div>
    </div>
  )
}

export default Switch
