import React from "react"
import "./academic.scss"

const academicData = [
  {
    certificate: "M.Sc in Computer Science and Engineering",
    time: "2022 - Present",
    name: "East Delta University",
    cgpa: "CGPA 3.83 out of 4.0",
  },
  {
    certificate: "B.Sc in Computer Science and Engineering",
    time: "2016 - 2020",
    name: "Port City International University",
    cgpa: "CGPA 3.86 out of 4.0",
  },
  {
    certificate: "HSC",
    time: "2013 - 2015",
    name: "Hajera-Taju Degree College",
    cgpa: "GPA 4.42 out of 5.0",
  },
  {
    certificate: "SSC",
    time: "2012 - 2013",
    name: "Chittagong Govt. School",
    cgpa: "GPA 5.00 out of 5.0",
  },
]

const Academic = () => (
  <section id="academic" className="academic active">
    <section className="section experience">
      <div className="section__title">Academic Qualification</div>
      <div className="section__content">
        <div className="jobs">
          {academicData.map(data => (
            <div className="job" key={data.name}>
              <div className="time-place">
                <div className="job__certificate">{data.certificate}</div>
                <div className="job__time">{data.time}</div>
              </div>
              <div className="job__name">{data.name}</div>
              <div className="job__cgpa">{data.cgpa}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  </section>
)

export default Academic
