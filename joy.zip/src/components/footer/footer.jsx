import React from "react"
import "./footer.scss"

const socialData = [
  {
    title: "email",
    url: "mailto:usmanjoycse@gmail.com",
  },
  {
    title: "linkedin",
    url: "https://www.linkedin.com/in/usman-gani-joy-975622120/",
  },
]
const Footer = () => (
  <footer className="footer">
    <div className="footer__copyright">
      <div className="top">
        <span>Developed by&nbsp;</span>
      </div>
      <div className="bottom">
        <span>Usman Gani Joy</span>
        <img className="emoji" src="./images/emojis/rockon.png" alt="emoji" />
        <span>2024</span>
      </div>
      <div className="bottom-credits">
        <small>
          Thanks to
          <a
            href="https://github.com/skavinvarnan"
            rel="noreferrer"
            target="_blank"
          >
            {" "}
            Kavin Varnan
          </a>
          for the inspiration.
        </small>
      </div>
    </div>
    <div className="footer__links">
      {socialData.map(social => (
        <a
          key={social.title}
          href={social.url}
          target="_blank"
          rel="noreferrer"
          title="{{link.title}}"
        >
          <span className="text">{social.title}</span>
        </a>
      ))}
    </div>
  </footer>
)

export default Footer
