import React from "react"
import "./trainingCertificate.scss"

const trainingCertificateData = [
  {
    name: "Google IT Support Specialization, Offered by Google in Coursera",
    time: "2020",
    url: "https://shorturl.at/yFGSW",
  },
  {
    name: "Govt. Cross Platform Mobile App Development",
    time: "2022",
    url: null,
  },
  {
    name: "Think in a Redux way Course",
    time: "2023",
    url: "https://shorturl.at/iHQ18",
  },
  {
    name: "PostgreSQL for Everybody Specialization by University of Michigan",
    time: "2023",
    url: "https://shorturl.at/ptHMW",
  },
]

const TrainingCertificate = () => (
  <section id="certificate" className="academic active">
    <section className="section experience">
      <div className="section__title">Training & Certificate</div>
      <div className="section__content">
        <div className="jobs">
          {trainingCertificateData.map((data, index) => (
            <div className="job" key={index}>
              <div className="time-place">
                <div className="job__company">{data.name}</div>
                <div className="job__time"> Completion Year: {data.time}</div>
              </div>
              {data.url ? (
                <a
                  href={data.url}
                  className="job__url"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Credential URL
                </a>
              ) : (
                <div className="job__url"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  </section>
)

export default TrainingCertificate
