import React from "react"
import { Link } from "gatsby"
import Switch from "../switch/switch"
import "./navbar.scss"

const Navbar = ({ darkMode, setDarkMode }) => {
  const handleSwitchToggle = () => {
    setDarkMode(!darkMode)
  }

  return (
    <nav className={`navbar ${darkMode ? "dark-mode" : ""}`}>
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          JOY
        </Link>
        <div className="navbar-menu">
          <div className="navbar-start">
            <Link to="#skills" className="navbar-item" activeClassName="active">
              Skills
            </Link>
            <Link
              to="#experience"
              className="navbar-item"
              activeClassName="active"
            >
              Experience
            </Link>
            <Link
              to="#academic"
              className="navbar-item"
              activeClassName="active"
            >
              Academic
            </Link>
            <Link
              to="#certificate"
              className="navbar-item"
              activeClassName="active"
            >
              Certificate
            </Link>
            <Link
              to="#projects"
              className="navbar-item"
              activeClassName="active"
            >
              Projects
            </Link>
            <a href="./resume.pdf" target="_blank" rel="noreferrer">
              Resume
            </a>
          </div>
        </div>
        <div className="navbar-end">
          <Switch className="switch" handleToggle={handleSwitchToggle} />
        </div>
      </div>
    </nav>
  )
}

export default Navbar
