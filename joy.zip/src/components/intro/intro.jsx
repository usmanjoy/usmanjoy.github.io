import React from "react"
import { StaticImage } from "gatsby-plugin-image"
import "./intro.scss"

const introData = {
  title: "Hello! ",
  beforeName: "I'm ",
  name: "MD. Usman Gani Joy",
  afterName:
    ", an enthusiastic researcher and a passionate developer researching on AI and ML.",
  contact: "Get in touch ",
  email: "usmanjoycse@gmail.com",
  mailTo: "mailto:usmanjoycse@gmail.com",
}

const Intro = () => {
  const [isHovering, setIsHovering] = React.useState(false)

  const onMouseOver = () => {
    setIsHovering(true)
  }

  const onMouseOut = () => {
    setIsHovering(false)
  }

  React.useEffect(() => {
    setTimeout(() => {
      setIsHovering(true)
      setTimeout(() => {
        setIsHovering(false)
      }, 2000)
    }, 1000)
  }, [])

  return (
    <header className="intro">
      <div className="intro__content">
        <h1 className="intro__hello">
          <span>{introData.title}</span>
          <span
            className={
              isHovering
                ? "emoji wave-hand animated wave"
                : "emoji wave-hand animated"
            }
            onMouseOver={onMouseOver}
            onFocus={onMouseOver}
            onMouseOut={onMouseOut}
            onBlur={onMouseOut}
            role="button"
            aria-label="wave hand"
            tabIndex={0}
          ></span>
        </h1>

        <h2 className="intro__tagline">
          {introData.beforeName}
          <span className="name">{introData.name}</span>
          {introData.afterName}
          <span className="emoji technologist"></span>
        </h2>

        <h3 className="intro__contact">
          <span>{introData.contact}</span>
          <span className="emoji pointer"></span>
          <span>
            <a href={introData.mailTo} className="highlight-link">
              {introData.email}
            </a>
          </span>
        </h3>
      </div>

      <div
        className={`intro__image ${isHovering ? "hover" : ""}`}
        onMouseOver={onMouseOver}
        onMouseOut={onMouseOut}
        onFocus={onMouseOver}
        onBlur={onMouseOut}
        tabIndex={0}
        role="button"
      >
        <div className="wrapper">
          <StaticImage
            className={`img ${isHovering ? "hover" : ""}`}
            src="../../img/joy.JPG"
            width={500}
            quality={95}
            formats={["AUTO", "WEBP", "AVIF"]}
            alt="Headshot"
            style={{ maxWidth: "100%", height: "auto" }}
          />
        </div>
      </div>
    </header>
  )
}

export default Intro
