import React from "react"
import "./experience.scss"

const experienceData = [
  {
    company: "Upwork/Freelancer",
    url: "https://upwork.com/",
    time: "November 2019 - Present",
    position: "Freelancer (Deep Learning, ML/AI consultant)",
  },
]

const Experience = () => (
  <section id="experience" className="academic active">
    <section className="section experience">
      <div className="section__title">Experience</div>
      <div className="section__content">
        <div className="jobs">
          {experienceData.map(data => (
            <div className="job" key={data.company}>
              <div className="time-place">
                <div className="job__company">{data.position}</div>
                <div className="job__time">{data.time}</div>
              </div>
            </div>
          ))}
        </div>

        <a
          href="./resume.pdf"
          target="_blank"
          rel="noreferrer"
          className="arrow-link"
        >
          View My Resume
        </a>
      </div>
    </section>
  </section>
)

export default Experience
