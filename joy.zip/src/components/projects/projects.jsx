import React from "react"
import Parser from "html-react-parser"
import "./projects.scss"

const ProjectsData = [
  {
    name: "Increasing Profitability in the Streaming Service Industry Using Predictive Customer Churn Modeling",
    url: "",
    description:
      "Employed advanced ML techniques to predict customer churn in streaming services, achieving 97% AUC. Utilized LSTM, XG-Boost,Light-GBM and various Deep learning algorithms, addressing data imbalance with SMOTE and proposed Hybrid Model. Employed explainable AI for insights and evaluated model performance in real-world scenarios. Demonstrated the impact of big data analysis on customer retention strategies. A forthcoming paper will soon be published in the IEEE Access journal.",
    used: [
      { thing: "Python" },
      { thing: "PySpark" },
      { thing: "Scikit-Learn" },
      { thing: "LightGBM" },
      { thing: "XGBoost" },
      { thing: "TensorFlow" },
      { thing: "Keras" },
      { thing: "Lime" },
      { thing: "SHAP" },
    ],
  },
  {
    name: "Liver Tumor Segmentation in Deep Learning",
    url: "",
    description:
      "Employed deep neural network UNet for accurate CT liver tumor segmentation. Adapted VGG-16 for image classification to enhance UNet's performance.",
    used: [
      { thing: "Python" },
      { thing: "PyTorch" },
      { thing: "U-Net" },
      { thing: "VGG-16" },
    ],
  },
  {
    name: "Patenga Wind Power Prediction and Forecasting",
    url: "",
    description:
      "Utilized XGBoost, Random Forest, and LSTM deep learning model to forecast wind power from real-world Patenga data. Co-authored a forthcoming paper on the project.",
    used: [
      { thing: "Python" },
      { thing: "PyTorch" },
      { thing: "XGBoost" },
      { thing: "Random Forest" },
      { thing: "LSTM" },
    ],
  },
  {
    name: "Customer Behavior Analysis and Prediction in Big Data",
    url: "",
    description:
      "Analyzed a dataset of 2.87 lakh records from Sparkify (Udacity Data Scientist Nano Degree Program). Utilized Logistic Regression, Random Forest, and Gradient Boosted Tree Classifier to develop predictive models. Focused on customer churn identification using accuracy and F1 score metrics.",
    used: [
      { thing: "Python" },
      { thing: "PySpark" },
      { thing: "Scikit-Learn" },
      { thing: "Logistic Regression" },
      { thing: "Random Forest" },
      { thing: "Gradient Boosted Tree Classifier" },
    ],
  },
]

const Projects = () => (
  <section id="projects" className="academic active">
    <section className="section other-projects">
      <div className="section__title">Projects</div>
      <div className="section__content">
        {ProjectsData.map(project => (
          <div className="project" key={project.name}>
            <div className="project__name">{project.name}</div>
            <p>{Parser(project.description)}</p>
            <div className="project__used">
              {project.used.map(item => (
                <span key={item.thing} className="project__used__item">
                  {item.thing}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  </section>
)

export default Projects
