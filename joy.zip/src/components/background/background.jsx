import React from "react"
const backgroundData = {
  title: "Background",
  part1:
    "Greetings! I'm Usman Gani Joy, passionate about the exciting realm of machine learning. Currently in my final year pursuing an M.Sc in Computer Science and Engineering at East Delta University, I'm dedicated to pushing the boundaries of knowledge in this field.",
  part2:
    "I'm thrilled to share that I've recently submitted a research paper to IEEE Access",
  part2Href: "(https://ieeeaccess.ieee.org/)",
  part3:
    " for review, showcasing my commitment to academic excellence. Alongside my studies, I engage in freelance projects related to ML/AI and serve as a proficient data analyst.",
  line2:
    "My expertise lies in areas such as big data, transfer learning, deep learning, and customer churn analysis",
}
const Background = () => (
  <section className="section background">
    <div className="section__title">{backgroundData.title}</div>
    <div className="section__content">
      <p>
        {backgroundData.part1}
        <a
          className="underline-link"
          href={backgroundData.part2Href}
          target="_blank"
          rel="noreferrer"
        >
          {backgroundData.part2}
        </a>
        {backgroundData.part3}
      </p>
      <p>{backgroundData.line2}</p>
      <p>
        <strong>{backgroundData.line3Part1}</strong>
        {backgroundData.line3Part2}
        <a
          className="underline-link"
          href={backgroundData.line3Part3Href}
          target="_blank"
          rel="noreferrer"
        >
          {backgroundData.line3Part3}
        </a>
        {backgroundData.line3Part4}
      </p>
    </div>
  </section>
)

export default Background
