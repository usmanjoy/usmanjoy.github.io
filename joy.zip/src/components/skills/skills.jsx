import React from "react"
import "./skills.scss"

const skillsData = {
  languagesTitle: "Frontend",
  languages: ["Flutter", "React", "Redux"],
  frameworksTitle: "Backend",
  frameworks: ["Node.js", "Python", "Asp Net Core Web API"],
  toolsTitle: "Servers",
  tools: ["Scaling", "Microservice", "Monolith"],
  MachineLearning: "Machine Learning",
  MachineLearningTools: [
    "Pytorch",
    "Tensorflow",
    "Keras",
    "Scikit-learn",
    "Pandas",
    "Numpy",
  ],
  bigDataTitle: "Big Data",
  bigDataTool: ["Pyspark"],
}

const Skills = () => (
  <section id="skills" className="academic active">
    <section className="section skills">
      <div className="section__title">Skills</div>
      <div className="section__content">
        <div className="skillz">
          <div className="skillz__category">
            <div className="skillz__category__label">
              {skillsData.languagesTitle}
            </div>
            <ul>
              {skillsData.languages.map((data, i) => (
                <li className="skillz__category__item" key={i}>
                  {data}
                </li>
              ))}
            </ul>
          </div>
          <div className="skillz__category">
            <div className="skillz__category__label">
              {skillsData.frameworksTitle}
            </div>
            <ul>
              {skillsData.frameworks.map((data, i) => (
                <li className="skillz__category__item" key={i}>
                  {data}
                </li>
              ))}
            </ul>
          </div>
          <div className="skillz__category">
            <div className="skillz__category__label">
              {skillsData.toolsTitle}
            </div>
            <ul>
              {skillsData.tools.map((data, i) => (
                <li className="skillz__category__item" key={i}>
                  {data}
                </li>
              ))}
            </ul>
          </div>
          <div className="skillz__category">
            <div className="skillz__category__label">
              {skillsData.MachineLearning}
            </div>
            <ul>
              {skillsData.MachineLearningTools.map((data, i) => (
                <li className="skillz__category__item" key={i}>
                  {data}
                </li>
              ))}
            </ul>
          </div>
          <div className="skillz__category">
            <div className="skillz__category__label">
              {skillsData.bigDataTitle}
            </div>
            <ul>
              {skillsData.bigDataTool.map((data, i) => (
                <li className="skillz__category__item" key={i}>
                  {data}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  </section>
)

export default Skills
